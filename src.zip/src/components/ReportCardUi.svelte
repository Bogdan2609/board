<script lang="ts">
	import {
		Container,
		Rectangle,
		Text,
	} from 'pixi-svelte';

	import { getContext } from '../game/context';
	import { UI_LAYOUT } from '../game/uiLayout';

	const context = getContext();

	type LayoutType =
		| 'desktop'
		| 'tablet'
		| 'landscape'
		| 'portrait';

	/*
	 * Должно совпадать с mainSizesMap в stateLayout.ts.
	 *
	 * Нам нужна именно логическая высота MainContainer,
	 * а не физическая высота browser screenshot.
	 */
	const MAIN_HEIGHT_BY_LAYOUT: Record<LayoutType, number> = {
		desktop: 800,
		tablet: 1000,
		landscape: 900,
		portrait: 1422,
	};

	const board = $derived(
		context.stateGameDerived.boardLayout(),
	);

	const layoutType = $derived(
		context.stateLayoutDerived.layoutType() as LayoutType,
	);

	const mainHeight = $derived(
		MAIN_HEIGHT_BY_LAYOUT[layoutType],
	);

	// =========================================================
	// BOARD BOUNDS
	// =========================================================

	const boardLeft = $derived(
		board.x - board.width / 2,
	);

	const boardRight = $derived(
		board.x + board.width / 2,
	);

	const boardTop = $derived(
		board.y - board.height / 2,
	);

	// =========================================================
	// COMMON BOTTOM LINE
	// =========================================================

	/*
	 * Все нижние элементы заканчиваются на этой координате.
	 *
	 * BET   ─────┐
	 * WIN   ─────┼── hudBottomY
	 * FAST  ─────┘
	 */
	const hudBottomY = $derived(
		mainHeight - UI_LAYOUT.bottom.bottomOffset,
	);

	// =========================================================
	// LEFT TOP
	// =========================================================

	const leftX = $derived(
		boardLeft -
			UI_LAYOUT.leftPanel.width -
			28,
	);

	const leftY = $derived(
		boardTop + 35,
	);

	// =========================================================
	// LEFT BOTTOM
	// =========================================================

	// BET касается общей нижней линии.
	const betY = $derived(
		hudBottomY -
			UI_LAYOUT.leftStats.height,
	);

	// BALANCE над BET.
	const balanceY = $derived(
		betY -
			UI_LAYOUT.leftStats.gap -
			UI_LAYOUT.leftStats.height,
	);

	// Utility buttons над BALANCE.
	const utilityY = $derived(
		balanceY -
			UI_LAYOUT.leftButtons.statsGap -
			UI_LAYOUT.leftButtons.buttonSize,
	);

	// =========================================================
	// WIN
	// =========================================================

	const winX = $derived(
		boardLeft,
	);

	/*
	 * WIN тоже касается общей нижней линии.
	 */
	const winY = $derived(
		hudBottomY -
			UI_LAYOUT.winPanel.height,
	);

	const winWidth = $derived(
		board.width,
	);

	// =========================================================
	// RIGHT BOTTOM
	// =========================================================

	const rightX = $derived(
		boardRight +
			UI_LAYOUT.rightPanel.boardGapX,
	);

	/*
	 * FAST касается общей нижней линии.
	 */
	const fastY = $derived(
		hudBottomY -
			UI_LAYOUT.rightPanel.fastHeight,
	);

	/*
	 * SPIN располагается непосредственно над FAST.
	 */
	const spinY = $derived(
		fastY -
			UI_LAYOUT.rightPanel.gap -
			UI_LAYOUT.rightPanel.spinHeight,
	);

	// =========================================================
	// COLORS
	// =========================================================

	const INK = 0x26211d;

	const PAPER = 0xfff4d8;
	const YELLOW = 0xffe37e;
	const BLUE = 0xd9efff;
	const GREEN = 0x54a84f;
	const PURPLE = 0xe4d4f1;
	const RED = 0xd84a3e;

	const SHADOW = 0x291d13;
</script>

<Container>

	<!-- =========================================================
		LEFT TOP
		BUY FREE SPINS + BASE / ANTE
	========================================================= -->

	<Container
		x={leftX}
		y={leftY}
	>
		<!-- =====================================================
			BUY FREE SPINS
		===================================================== -->

		<!-- shadow -->
		<Rectangle
			x={6}
			y={7}
			width={UI_LAYOUT.leftPanel.width}
			height={135}
			backgroundColor={SHADOW}
			backgroundAlpha={0.22}
		/>

		<!-- yellow paper -->
		<Rectangle
			x={0}
			y={0}
			width={UI_LAYOUT.leftPanel.width}
			height={135}
			backgroundColor={YELLOW}
			borderColor={INK}
			borderWidth={3}
		/>

		<!-- tape left -->
		<Rectangle
			x={18}
			y={-8}
			width={56}
			height={20}
			rotation={-0.1}
			backgroundColor={0x70aace}
			backgroundAlpha={0.85}
		/>

		<!-- tape right -->
		<Rectangle
			x={UI_LAYOUT.leftPanel.width - 74}
			y={-7}
			width={56}
			height={20}
			rotation={0.09}
			backgroundColor={0x70aace}
			backgroundAlpha={0.85}
		/>

		<Text
			x={UI_LAYOUT.leftPanel.width / 2}
			y={27}
			anchor={{
				x: 0.5,
				y: 0,
			}}
			text="BUY"
			style={{
				fontFamily: 'Comic Sans MS',
				fontSize: 21,
				fontWeight: '700',
				fill: INK,
			}}
		/>

		<Text
			x={UI_LAYOUT.leftPanel.width / 2}
			y={56}
			anchor={{
				x: 0.5,
				y: 0,
			}}
			text="FREE SPINS"
			style={{
				fontFamily: 'Comic Sans MS',
				fontSize: 25,
				fontWeight: '700',
				fill: RED,
			}}
		/>

		<Text
			x={UI_LAYOUT.leftPanel.width / 2}
			y={99}
			anchor={{
				x: 0.5,
				y: 0,
			}}
			text="★ ★ ★"
			style={{
				fontFamily: 'Arial',
				fontSize: 17,
				fontWeight: '700',
				fill: 0xd49a18,
			}}
		/>


		<!-- =====================================================
			BASE / ANTE
		===================================================== -->

		<Rectangle
			x={6}
			y={162}
			width={UI_LAYOUT.leftPanel.width}
			height={105}
			backgroundColor={SHADOW}
			backgroundAlpha={0.22}
		/>

		<Rectangle
			x={0}
			y={155}
			width={UI_LAYOUT.leftPanel.width}
			height={105}
			backgroundColor={BLUE}
			borderColor={INK}
			borderWidth={3}
		/>

		<Text
			x={UI_LAYOUT.leftPanel.width / 2}
			y={168}
			anchor={{
				x: 0.5,
				y: 0,
			}}
			text="BASE"
			style={{
				fontFamily: 'Comic Sans MS',
				fontSize: 21,
				fontWeight: '700',
				fill: INK,
			}}
		/>

		<Text
			x={UI_LAYOUT.leftPanel.width / 2}
			y={196}
			anchor={{
				x: 0.5,
				y: 0,
			}}
			text="↔"
			style={{
				fontFamily: 'Arial',
				fontSize: 28,
				fontWeight: '700',
				fill: 0x315f89,
			}}
		/>

		<Text
			x={UI_LAYOUT.leftPanel.width / 2}
			y={226}
			anchor={{
				x: 0.5,
				y: 0,
			}}
			text="ANTE"
			style={{
				fontFamily: 'Comic Sans MS',
				fontSize: 21,
				fontWeight: '700',
				fill: INK,
			}}
		/>
	</Container>


	<!-- =========================================================
		LEFT UTILITY BUTTONS
	========================================================= -->

	<Container
		x={leftX}
		y={utilityY}
	>
		<!-- SOUND -->
		<Rectangle
			x={0}
			y={0}
			width={UI_LAYOUT.leftButtons.buttonSize}
			height={UI_LAYOUT.leftButtons.buttonSize}
			backgroundColor={PAPER}
			borderColor={INK}
			borderWidth={3}
		/>

		<Text
			x={UI_LAYOUT.leftButtons.buttonSize / 2}
			y={UI_LAYOUT.leftButtons.buttonSize / 2}
			anchor={0.5}
			text="🔊"
			style={{
				fontSize: 23,
				fill: INK,
			}}
		/>


		<!-- INFO -->
		<Rectangle
			x={
				UI_LAYOUT.leftButtons.buttonSize +
				UI_LAYOUT.leftButtons.gap
			}
			y={0}
			width={UI_LAYOUT.leftButtons.buttonSize}
			height={UI_LAYOUT.leftButtons.buttonSize}
			backgroundColor={BLUE}
			borderColor={INK}
			borderWidth={3}
		/>

		<Text
			x={
				UI_LAYOUT.leftButtons.buttonSize +
					UI_LAYOUT.leftButtons.gap +
					UI_LAYOUT.leftButtons.buttonSize / 2
			}
			y={UI_LAYOUT.leftButtons.buttonSize / 2}
			anchor={0.5}
			text="i"
			style={{
				fontFamily: 'Georgia',
				fontSize: 29,
				fontWeight: '700',
				fill: 0x245f9b,
			}}
		/>


		<!-- MENU -->
		<Rectangle
			x={
				(
					UI_LAYOUT.leftButtons.buttonSize +
						UI_LAYOUT.leftButtons.gap
				) * 2
			}
			y={0}
			width={UI_LAYOUT.leftButtons.buttonSize}
			height={UI_LAYOUT.leftButtons.buttonSize}
			backgroundColor={PAPER}
			borderColor={INK}
			borderWidth={3}
		/>

		<Text
			x={
				(
					UI_LAYOUT.leftButtons.buttonSize +
						UI_LAYOUT.leftButtons.gap
				) * 2 +
					UI_LAYOUT.leftButtons.buttonSize / 2
			}
			y={UI_LAYOUT.leftButtons.buttonSize / 2}
			anchor={0.5}
			text="≡"
			style={{
				fontFamily: 'Arial',
				fontSize: 34,
				fontWeight: '700',
				fill: INK,
			}}
		/>
	</Container>


	<!-- =========================================================
		BALANCE
	========================================================= -->

	<Container
		x={leftX}
		y={balanceY}
	>
		<Rectangle
			x={5}
			y={5}
			width={UI_LAYOUT.leftStats.width}
			height={UI_LAYOUT.leftStats.height}
			backgroundColor={SHADOW}
			backgroundAlpha={0.18}
		/>

		<Rectangle
			x={0}
			y={0}
			width={UI_LAYOUT.leftStats.width}
			height={UI_LAYOUT.leftStats.height}
			backgroundColor={PAPER}
			borderColor={INK}
			borderWidth={3}
		/>

		<Text
			x={14}
			y={6}
			text="BALANCE"
			style={{
				fontFamily: 'Comic Sans MS',
				fontSize: 12,
				fontWeight: '700',
				fill: 0x315f89,
			}}
		/>

		<Text
			x={14}
			y={26}
			text="$1,234.56"
			style={{
				fontFamily: 'Comic Sans MS',
				fontSize: 21,
				fontWeight: '700',
				fill: INK,
			}}
		/>
	</Container>


	<!-- =========================================================
		BET
	========================================================= -->

	<Container
		x={leftX}
		y={betY}
	>
		<Rectangle
			x={5}
			y={5}
			width={UI_LAYOUT.leftStats.width}
			height={UI_LAYOUT.leftStats.height}
			backgroundColor={SHADOW}
			backgroundAlpha={0.18}
		/>

		<Rectangle
			x={0}
			y={0}
			width={UI_LAYOUT.leftStats.width}
			height={UI_LAYOUT.leftStats.height}
			backgroundColor={BLUE}
			borderColor={INK}
			borderWidth={3}
		/>

		<Text
			x={14}
			y={6}
			text="BET"
			style={{
				fontFamily: 'Comic Sans MS',
				fontSize: 12,
				fontWeight: '700',
				fill: 0x315f89,
			}}
		/>

		<Text
			x={14}
			y={26}
			text="$2.00"
			style={{
				fontFamily: 'Comic Sans MS',
				fontSize: 21,
				fontWeight: '700',
				fill: INK,
			}}
		/>
	</Container>


	<!-- =========================================================
		WIN
		LOWER EDGE = hudBottomY
	========================================================= -->

	<Container
		x={winX}
		y={winY}
	>
		<Rectangle
			x={5}
			y={5}
			width={winWidth}
			height={UI_LAYOUT.winPanel.height}
			backgroundColor={SHADOW}
			backgroundAlpha={0.18}
		/>

		<Rectangle
			x={0}
			y={0}
			width={winWidth}
			height={UI_LAYOUT.winPanel.height}
			backgroundColor={PURPLE}
			borderColor={INK}
			borderWidth={3}
		/>

		<Text
			x={winWidth / 2}
			y={7}
			anchor={{
				x: 0.5,
				y: 0,
			}}
			text="WIN"
			style={{
				fontFamily: 'Comic Sans MS',
				fontSize: 13,
				fontWeight: '700',
				fill: 0x674881,
			}}
		/>

		<Text
			x={winWidth / 2}
			y={27}
			anchor={{
				x: 0.5,
				y: 0,
			}}
			text="$0.00"
			style={{
				fontFamily: 'Comic Sans MS',
				fontSize: 24,
				fontWeight: '700',
				fill: INK,
			}}
		/>
	</Container>


	<!-- =========================================================
		RIGHT SPIN
	========================================================= -->

	<Container
		x={rightX}
		y={spinY}
	>
		<!-- shadow -->
		<Rectangle
			x={7}
			y={8}
			width={UI_LAYOUT.rightPanel.spinWidth}
			height={UI_LAYOUT.rightPanel.spinHeight}
			backgroundColor={SHADOW}
			backgroundAlpha={0.28}
		/>

		<!-- button -->
		<Rectangle
			x={0}
			y={0}
			width={UI_LAYOUT.rightPanel.spinWidth}
			height={UI_LAYOUT.rightPanel.spinHeight}
			backgroundColor={GREEN}
			borderColor={INK}
			borderWidth={5}
		/>

		<Text
			x={UI_LAYOUT.rightPanel.spinWidth / 2}
			y={UI_LAYOUT.rightPanel.spinHeight / 2}
			anchor={0.5}
			text="↻"
			style={{
				fontFamily: 'Arial',
				fontSize: 100,
				fontWeight: '700',
				fill: 0xffffff,
				stroke: {
					color: 0x315e31,
					width: 4,
				},
			}}
		/>
	</Container>


	<!-- =========================================================
		FAST
		LOWER EDGE = hudBottomY
	========================================================= -->

	<Container
		x={rightX}
		y={fastY}
	>
		<Rectangle
			x={5}
			y={5}
			width={UI_LAYOUT.rightPanel.spinWidth}
			height={UI_LAYOUT.rightPanel.fastHeight}
			backgroundColor={SHADOW}
			backgroundAlpha={0.18}
		/>

		<Rectangle
			x={0}
			y={0}
			width={UI_LAYOUT.rightPanel.spinWidth}
			height={UI_LAYOUT.rightPanel.fastHeight}
			backgroundColor={PAPER}
			borderColor={INK}
			borderWidth={3}
		/>

		<Text
			x={22}
			y={UI_LAYOUT.rightPanel.fastHeight / 2}
			anchor={0.5}
			text="+"
			style={{
				fontFamily: 'Arial',
				fontSize: 26,
				fontWeight: '700',
				fill: INK,
			}}
		/>

		<Text
			x={UI_LAYOUT.rightPanel.spinWidth / 2}
			y={UI_LAYOUT.rightPanel.fastHeight / 2}
			anchor={0.5}
			text="⚡ FAST"
			style={{
				fontFamily: 'Comic Sans MS',
				fontSize: 16,
				fontWeight: '700',
				fill: INK,
			}}
		/>

		<Text
			x={UI_LAYOUT.rightPanel.spinWidth - 22}
			y={UI_LAYOUT.rightPanel.fastHeight / 2}
			anchor={0.5}
			text="−"
			style={{
				fontFamily: 'Arial',
				fontSize: 26,
				fontWeight: '700',
				fill: INK,
			}}
		/>
	</Container>

</Container>
