export const UI_LAYOUT = {
	leftPanel: {
		width: 220,
	},

	leftButtons: {
		buttonSize: 52,
		gap: 12,
		statsGap: 12,
	},

	leftStats: {
		width: 195,
		height: 56,
		gap: 8,
	},

	winPanel: {
		height: 62,
	},

	rightPanel: {
		spinWidth: 170,
		spinHeight: 175,

		fastHeight: 54,

		gap: 12,
		boardGapX: 75,
	},

	bottom: {
		// Отступ всей нижней линии HUD от края MainContainer.
		bottomOffset: 14,
	},
} as const;
